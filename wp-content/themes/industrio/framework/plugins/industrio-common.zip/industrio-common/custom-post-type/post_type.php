<?php
// register post type Project
add_action( 'init', 'register_industrio_Project' );
function register_industrio_Project() {
    
    $labels = array( 
        'name' => __( 'Project', 'industrio' ),
        'singular_name' => __( 'Project', 'industrio' ),
        'add_new' => __( 'Add New Project', 'industrio' ),
        'add_new_item' => __( 'Add New Project', 'industrio' ),
        'edit_item' => __( 'Edit Project', 'industrio' ),
        'new_item' => __( 'New Project', 'industrio' ),
        'view_item' => __( 'View Project', 'industrio' ),
        'search_items' => __( 'Search Project', 'industrio' ),
        'not_found' => __( 'No Project found', 'industrio' ),
        'not_found_in_trash' => __( 'No Project found in Trash', 'industrio' ),
        'parent_item_colon' => __( 'Parent Project:', 'industrio' ),
        'menu_name' => __( 'Project', 'industrio' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Project',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Project', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Project', $args );
}
add_action( 'init', 'create_type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'type', 'industrio' ),
    'singular_name' => __( 'type', 'industrio' ),
    'search_items' =>  __( 'Search type','industrio' ),
    'all_items' => __( 'All type','industrio' ),
    'parent_item' => __( 'Parent type','industrio' ),
    'parent_item_colon' => __( 'Parent type:','industrio' ),
    'edit_item' => __( 'Edit type','industrio' ), 
    'update_item' => __( 'Update type','industrio' ),
    'add_new_item' => __( 'Add New type','industrio' ),
    'new_item_name' => __( 'New type Name','industrio' ),
    'menu_name' => __( 'type','industrio' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Project'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}


// register post type1 Service
add_action( 'init', 'register_industrio_Service' );
function register_industrio_Service() {
    
    $labels = array( 
        'name' => __( 'Service', 'industrio' ),
        'singular_name' => __( 'Service', 'industrio' ),
        'add_new' => __( 'Add New Service', 'industrio' ),
        'add_new_item' => __( 'Add New Service', 'industrio' ),
        'edit_item' => __( 'Edit Service', 'industrio' ),
        'new_item' => __( 'New Service', 'industrio' ),
        'view_item' => __( 'View Service', 'industrio' ),
        'search_items' => __( 'Search Service', 'industrio' ),
        'not_found' => __( 'No Service found', 'industrio' ),
        'not_found_in_trash' => __( 'No Service found in Trash', 'industrio' ),
        'parent_item_colon' => __( 'Parent Service:', 'industrio' ),
        'menu_name' => __( 'Service', 'industrio' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Service',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Service', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/img/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Service', $args );
}
add_action( 'init', 'create_type1_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_type1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'type1', 'industrio' ),
    'singular_name' => __( 'type1', 'industrio' ),
    'search_items' =>  __( 'Search type1','industrio' ),
    'all_items' => __( 'All type1','industrio' ),
    'parent_item' => __( 'Parent type1','industrio' ),
    'parent_item_colon' => __( 'Parent type1:','industrio' ),
    'edit_item' => __( 'Edit type1','industrio' ), 
    'update_item' => __( 'Update type1','industrio' ),
    'add_new_item' => __( 'Add New type1','industrio' ),
    'new_item_name' => __( 'New type1 Name','industrio' ),
    'menu_name' => __( 'type1','industrio' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Service'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));

}

?>