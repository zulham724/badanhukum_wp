<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
$textdomain = "industrio";
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';
	
  
   
    // Add other metaboxes as needed
    
    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Link facebook',
                'desc' => 'Input Link facebook',
                'id'   => $prefix . 'single_facebook',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link twitter',
                'desc' => 'Input Link twitter',
                'id'   => $prefix . 'single_twitter',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link google plus',
                'desc' => 'Input Link google plus',
                'id'   => $prefix . 'single_google',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link dribbble',
                'desc' => 'Input Link dribbble',
                'id'   => $prefix . 'single_dribbble',
                'type'    => 'text',
            ),
            array(
                'name' => 'Featured Image 2',
                'desc' => 'Horizontale Image: show in homepage',
                'id'   => $prefix . 'featured_image_2',
                'type'    => 'file',
            ),
          
        )
    );



$meta_boxes[] = array(
        'id'         => 'project_setting',
        'title'      => 'Project Setting',
        'pages'      => array('Project'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
             array(
                'name' => 'Title of project',
                'desc' => 'Input title of project',
                'id'   => $prefix . 'title',
                'type'    => 'text',
            ),
             array(
                'name' => 'Link',
                'desc' => 'Input link',
                'id'   => $prefix . 'link',
                'type'    => 'text',
            ),
          
        )
    );

$meta_boxes[] = array(
        'id'         => 'service_setting',
        'title'      => 'Service Setting',
        'pages'      => array('Service'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
             array(
                'name' => 'Featured Image 2',
                'desc' => 'Show in service page',
                'id'   => $prefix . 'service_featured_image_2',
                'type'    => 'file',
            ),
             array(
                'name' => 'Icon',
                'desc' => '',
                'id'   => $prefix . 'icon',
                'type'    => 'text',
            ),
          
        )
    );


	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

} 